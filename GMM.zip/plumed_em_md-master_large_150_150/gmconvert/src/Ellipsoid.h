/*
 
 <Ellipsoid.h>

*/

extern void write__GAUSS3Ds_in_ellipsoid_VRML();


