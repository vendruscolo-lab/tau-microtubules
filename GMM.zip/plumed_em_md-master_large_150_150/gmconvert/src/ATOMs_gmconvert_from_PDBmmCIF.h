/*

 <ATOMs_gmconvert_from_PDBmmCIF.h>
 
*/

/* FUNCTIONS (GLOBAL) */
extern void Read_mmCIF_File();
extern void make_ATOM_list_from_ASSEMBLY();
extern void make_ATOM_list_from_UNITMOLs();
