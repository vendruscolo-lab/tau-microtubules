/*

 <GmmAtomEM.h>

*/

/*** Functions (GLOBAL) ***/
extern void EM_optimize_GaussMix_For_Gaussian_Atoms();
extern void GaussMix_by_One_Atom_One_Gdf_Assignment();
extern float CorrCoeff_Bwn_Atoms_and_GMM();
