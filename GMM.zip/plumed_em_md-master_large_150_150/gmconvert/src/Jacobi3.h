/*

 <Jacobi3.h>

*/
/*** FUNCTIONS (GLOBAL) ***/
extern int Jacobi_Wilkinson3();
extern void Sort_Eigen_Value3();
extern void print_matrix3();
