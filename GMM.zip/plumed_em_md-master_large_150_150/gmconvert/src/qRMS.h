/*
 <qRMS.h>

*/

extern double Calculate_CRMS_Bwn_Two_ATOMs();
extern double Calculate_CRMS_Bwn_Two_ATOMs_Using_CA_With_Same_Rnum();
extern double Rotate_ATOMs();
extern void calculate_gcenter();
