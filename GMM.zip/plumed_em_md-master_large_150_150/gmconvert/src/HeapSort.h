/*

 <HeapSort.h>

*/
void HeapSort();
void HeapSort_NoIndex();
void HeapSort_Integer_NoIndex();
void HeapSort_Indirect();
void BestIndex();
