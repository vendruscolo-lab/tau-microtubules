/*

 <3DmapKmean.h>

*/

extern void K_Means_Clustering_for_3D_Map_Multiple_Start();
extern double K_Means_Clustering_for_3D_Map();
extern void Initialize_Gauss_From_Randomly_Chosen_Voxels();
