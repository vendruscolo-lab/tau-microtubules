/*
 <MCubeIO.h>
*/

extern int Output_MC_Faces_VRML();
extern void Output_MC_Faces_Object();
extern int Read_MC_Faces_Object();
extern int  Output_MC_Edges_VRML();
extern int  Output_MC_Faces_PDB();
extern int  Output_MC_Edges_PDB();


