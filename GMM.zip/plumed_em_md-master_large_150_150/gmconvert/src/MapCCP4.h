/*
 
 <MapCCP4.h>

*/

/*** FUNCTIONS (GLOBAL) ***/
extern void Read_Density_File();
extern int  Write_MapCCP4_File();
extern int  Write_MapCCP4_File_HtoN();
extern int  Write_MapCCP4_File_NtoH();
