/*

 <AtomKmean.h>

*/

extern void K_Means_Clustering_For_Atoms();
extern void K_Means_Clustering_For_Atoms_Multiple_Start();
