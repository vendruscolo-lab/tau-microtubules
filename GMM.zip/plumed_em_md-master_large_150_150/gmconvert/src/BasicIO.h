/*

<BasicIO.h>

*/

/*** Functions (GLOBAL) ***/
extern void Find_Filename_Core();
extern void Get_Part_Of_Line();
extern char *Get_Date_String();
extern double Get_Time_in_Second_by_Double();
extern void Set_END_DATE();
extern void Split_to_Words();
extern void RGBTstr_to_floatRGBT();
