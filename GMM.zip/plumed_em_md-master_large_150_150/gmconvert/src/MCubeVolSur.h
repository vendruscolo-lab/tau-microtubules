/*
 <MCubeVolSur.h>
*/

extern float Volume_Inside_Faces();
extern void Cal_Gcenter_Of_Vertexes();
extern float Area_Faces();
extern void MinMax_XYZ_of_MCVertex();
extern void setup_static_inout_variables_for_MCFaces();
extern void free_static_inout_variables_for_MCFaces();
extern void check_inside_MCFace_for_VOXEL();
extern void check_inside_MCFace_for_VOXEL_old();
extern void set_zero_for_higher_threshold_VOXEL();
