/**
 <Atom2Vox.h>

**/

extern void Malloc_Voxel_From_Min_Max();
extern void Get_Min_Max_From_Atoms();
extern void Set_Voxel_Value_By_Atoms();
extern void Malloc_Voxel_From_Atoms();
