/*

 <3DmapEM.h>

*/

/*** Functions (GLOBAL) ***/
extern int  EM_optimize_GaussMix_for_Gaussian_3D_Map();
extern double Corr_Coeff_Bwn_VoxelGMM_and_GMM();
extern int GaussMix_by_One_Voxel_One_Gdf_Assignment();
extern void cal_sumDensity_and_Nvox_posi_dens();
